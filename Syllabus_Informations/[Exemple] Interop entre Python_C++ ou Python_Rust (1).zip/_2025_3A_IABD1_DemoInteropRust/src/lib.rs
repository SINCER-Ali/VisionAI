
struct MyLinearModel {
    a: f32,
    b: f32,
}

impl MyLinearModel {
    fn new(a: f32, b: f32) -> Self {
        MyLinearModel {
            a,
            b,
        }
    }

    fn predict(&self) -> f32 {
        self.a + self.b
    }
}


#[unsafe(no_mangle)]
extern "C" fn create_linear_model(a: f32, b: f32) -> *mut MyLinearModel {
    let model = Box::new(MyLinearModel::new(a, b));

    Box::into_raw(model)
}

#[unsafe(no_mangle)]
extern "C" fn predict_linear_model(model: *mut MyLinearModel) -> f32 {
    let model_ref = unsafe {
        model.as_ref().unwrap()
    };

    model_ref.predict()
}

#[unsafe(no_mangle)]
extern "C" fn release_linear_model(model: *mut MyLinearModel) {
    unsafe {
        let _ = Box::from_raw(model);
    };
}

#[unsafe(no_mangle)]
extern "C" fn sum_array(array: *mut f32, array_length: i32) -> f32 {
    unsafe {
        std::slice::from_raw_parts(array, array_length as usize)
    }.iter().sum()
}

#[unsafe(no_mangle)]
extern "C" fn get_array_of_incrementing_numbers(array_length: i32) -> *mut f32 {
    let mut vec = (0..array_length)
        .map(|elt| elt as f32)
        .collect::<Vec<_>>();

    vec.shrink_to_fit();

    vec.leak().as_mut_ptr()
}

#[unsafe(no_mangle)]
extern "C" fn delete_array(array: *mut f32, array_length: i32) {
    unsafe {
        let _ = Vec::from_raw_parts(array, array_length as usize, array_length as usize);
    }
}


#[unsafe(no_mangle)]
extern "C" fn my_add(a: i32, b: i32) -> i32 {
    a + b
}